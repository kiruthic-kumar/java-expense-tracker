# Student Expense Tracker (Java Console App)

This is a beginner-friendly Java console application to manage personal finances by tracking income and expenses.

## 🚀 Features
- Add Income
- Add Expense
- View Current Balance
- View Transaction History
- Console-based menu system

## 💡 Concepts Used
- Java OOP (Classes, Objects)
- ArrayList
- Loops & Conditionals
- Scanner for Input
- Method Structuring

## 📁 Files
- `ExpenseTracker.java` – Main logic & menu
- `Transaction.java` – Data model for each entry

## 🛠️ How to Run
1. Clone/download the project.
2. Compile the files using any IDE (like IntelliJ or VS Code).
3. Run `ExpenseTracker.java` to start.

## 📄 License
This project is open for learning and sharing.